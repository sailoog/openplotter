Moitessier HAT Firmware
=======================

Firmware for the STM32F091 microcontroller on the Moitessier HAT.


Currently the firmware for the Moitessier HAT microcontroller will be revised. As soon as this process is finished, the source
code will be published. In the meantime you can use the precompiled binary.

Use the flasher tool to update the firmware of the microcontroller.
